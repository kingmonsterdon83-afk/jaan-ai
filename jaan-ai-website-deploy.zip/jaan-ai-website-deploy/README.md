# Jaan AI Website (static frontend)

Upload `index.html` to the root of a GitHub repository and enable GitHub Pages.

This frontend expects the FastAPI backend from the Jaan AI Android ZIP, hosted separately.

1. Deploy the backend to a hosting service that supports Python/FastAPI.
2. Keep `OPENAI_API_KEY` only on the backend environment. Never put it in this HTML.
3. Open the website, enter your backend base URL (without trailing slash), and Save.
4. Chat calls `POST /chat` with `{message, history}` and expects `{reply}`.

The backend must allow CORS for the website origin. Configure CORS on the backend before production use.
